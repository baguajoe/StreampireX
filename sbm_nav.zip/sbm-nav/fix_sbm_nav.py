#!/usr/bin/env python3
"""
fix_sbm_nav.py — Replace flat 22-tab nav with grouped dropdown nav
Run: python3 fix_sbm_nav.py
"""
import shutil, re, sys

SRC = '/workspaces/SpectraSphere/src/front/js/component'
SBM = f'{SRC}/SamplerBeatMaker.js'

shutil.copy2(SBM, SBM + '.bak.nav')

with open(SBM) as f:
    lines = f.readlines()

# 1. Find the nav block start and end lines
start_line = None
end_line = None

for i, line in enumerate(lines):
    if '4-TAB NAVIGATION' in line or ("sbm-tab-nav" in line and 'overflowX' in lines[i] if i < len(lines) else False):
        start_line = i
    if start_line and i > start_line:
        # Find the closing </div> of the tab nav — look for line with just ")}" after the .map
        if '  ].map(tab =>' in line:
            # Find closing of this map — look for the matching ])} 
            depth = 0
            for j in range(i, min(i + 80, len(lines))):
                if '].map(' in lines[j]: depth = 1
                if depth and '</div>' in lines[j] and 'sbm-tab-nav' not in lines[j]:
                    # Check if this closes the nav div
                    pass
                if depth and lines[j].strip() in ('</div>', '</div>\n'):
                    end_line = j
                    break
            break

# Simpler approach — find by known content
start_idx = None
end_idx = None

for i, line in enumerate(lines):
    if '4-TAB NAVIGATION' in line:
        start_idx = i
    if start_idx and i > start_idx + 5:
        if "{ id: 'stutter'" in line:
            # Find the closing </div> after stutter entry
            for j in range(i, min(i + 20, len(lines))):
                if lines[j].strip() in ('</div>', '</div>\n') or lines[j].strip().startswith('</div>'):
                    end_idx = j
                    break
            break

if start_idx is None or end_idx is None:
    print(f"ERROR: Could not find nav block. start={start_idx} end={end_idx}")
    print("Searching for nav block markers...")
    for i, line in enumerate(lines):
        if 'TAB NAVIGATION' in line or 'sbm-tab-nav' in line or "id: 'stutter'" in line:
            print(f"  Line {i+1}: {line.rstrip()}")
    sys.exit(1)

print(f"  Found nav block: lines {start_idx+1} to {end_idx+1}")

# 2. Build replacement lines
replacement = [
    "      {/* ═══ GROUPED DROPDOWN NAV ═══ */}\n",
    "      <SBMDropdownNav activeTab={activeTab} setActiveTab={setActiveTab} />\n",
]

# 3. Replace
new_lines = lines[:start_idx] + replacement + lines[end_idx+1:]

# 4. Add import after StutterEngine import
import_line = "import StutterEngine from './StutterEngine';\n"
import_new = "import StutterEngine from './StutterEngine';\nimport SBMDropdownNav from './SBMDropdownNav';\n"

content = ''.join(new_lines)
if 'SBMDropdownNav' not in content:
    content = content.replace(import_line, import_new, 1)
    print("  Added SBMDropdownNav import")
else:
    print("  Import already present")

with open(SBM, 'w') as f:
    f.write(content)

print(f"  Replaced {end_idx - start_idx + 1} lines with 2-line dropdown nav")
print("\nDone. Run: npm run build")
