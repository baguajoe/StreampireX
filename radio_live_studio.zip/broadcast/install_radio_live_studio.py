#!/usr/bin/env python3
"""
install_radio_live_studio.py
Wires RadioLiveStudio into StreamPireX
"""
import shutil, os

BASE = '/workspaces/SpectraSphere'
PAGES = f'{BASE}/src/front/js/pages'
STYLES = f'{BASE}/src/front/styles'
LAYOUT = f'{BASE}/src/front/js/layout.js'

# 1. Copy files
shutil.copy('RadioLiveStudio.js', f'{PAGES}/RadioLiveStudio.js')
shutil.copy('RadioLiveStudio.css', f'{STYLES}/RadioLiveStudio.css')
print("  Copied files")

# 2. Wire into layout.js
with open(LAYOUT) as f:
    content = f.read()

# Add import
old_import = "import GoLivePage from \"./pages/GoLivePage\";"
new_import = """import GoLivePage from "./pages/GoLivePage";
import RadioLiveStudio from "./pages/RadioLiveStudio";"""

if 'RadioLiveStudio' not in content:
    content = content.replace(old_import, new_import)
    print("  Added import")

# Add route
old_route = '<Route path="/go-live" element={<GoLivePage />} />'
new_route = """<Route path="/go-live" element={<GoLivePage />} />
                                <Route path="/radio-live-studio" element={<RadioLiveStudio />} />
                                <Route path="/radio-live-studio/:stationId" element={<RadioLiveStudio />} />"""

if '/radio-live-studio' not in content:
    content = content.replace(old_route, new_route)
    print("  Added routes")

# Add to full page list
old_full = "'/podcast-collab-room',"
new_full = "'/podcast-collab-room',\n        '/radio-live-studio',"

if "'/radio-live-studio'" not in content:
    content = content.replace(old_full, new_full)
    print("  Added to full page list")

with open(LAYOUT, 'w') as f:
    f.write(content)

# 3. Add "Go Live with Video" button to RadioStationDashboard
DASHBOARD = f'{PAGES}/RadioStationDashboard.js'
with open(DASHBOARD) as f:
    dash = f.read()

old_btn = "className={`station-action-btn ${station.is_live ? 'stop' : 'start'}`}"
new_btn = """className={`station-action-btn ${station.is_live ? 'stop' : 'start'}`}"""

# Add import for useNavigate if not present
if 'useNavigate' not in dash:
    dash = dash.replace(
        "import { useNavigate }",
        "import { useNavigate }"
    )

# Add Go Live Video button after the existing start/stop button
old_station_btn = """{station.is_live ? '⏹️ Stop' : '▶️ Start'}
                    </button>"""

new_station_btn = """{station.is_live ? '⏹️ Stop' : '▶️ Start'}
                    </button>
                    <a
                      href={`/radio-live-studio/${station.id}`}
                      className="station-action-btn video-live"
                      title="Go Live with Video"
                      style={{ textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 4 }}
                    >
                      📺 Live Studio
                    </a>"""

if 'Live Studio' not in dash:
    dash = dash.replace(old_station_btn, new_station_btn)
    print("  Added Live Studio button to dashboard")

with open(DASHBOARD, 'w') as f:
    f.write(dash)

# 4. Add to sidebar under Radio section
SIDEBAR = f'{BASE}/src/front/js/component/sidebar.js'
with open(SIDEBAR) as f:
    sidebar = f.read()

old_dj = '<MenuItem to="/dj-mixer" className={isActive("/dj-mixer") ? "active" : ""}>'
old_dj_line = '''        <MenuItem to="/dj-mixer" className={isActive("/dj-mixer") ? "active" : ""}>🎛 <span className="sidebar-label">DJ Mixer</span></MenuItem>
      </>)}'''

new_dj_line = '''        <MenuItem to="/dj-mixer" className={isActive("/dj-mixer") ? "active" : ""}>🎛 <span className="sidebar-label">DJ Mixer</span></MenuItem>
        <MenuItem to="/radio-live-studio" className={isActive("/radio-live-studio") ? "active" : ""}>📺 <span className="sidebar-label">Live Studio</span><MenuHint className="sidebar-hint">NEW</MenuHint></MenuItem>
      </>)}'''

if '/radio-live-studio' not in sidebar:
    sidebar = sidebar.replace(old_dj_line, new_dj_line)
    print("  Added to Radio section in sidebar")

with open(SIDEBAR, 'w') as f:
    f.write(sidebar)

print("\nDone. Run: npm run build")
