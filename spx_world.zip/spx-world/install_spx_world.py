#!/usr/bin/env python3
"""
install_spx_world.py
Wires World Mode (Bible + Map + World Nav) into SPXScriptPage.js
Run: python3 install_spx_world.py
"""
import shutil, os

SRC = '/workspaces/SpectraSphere/src/front/js'
PAGE = f'{SRC}/pages/SPXScriptPage.js'
COMP = f'{SRC}/components/spx-script'

shutil.copy2(PAGE, PAGE + '.bak.world')

with open(PAGE) as f:
    content = f.read()

# 1. Add imports
old_imports = "import { useScriptOffline } from \"../hooks/useScriptOffline\";"
new_imports = """import { useScriptOffline } from "../hooks/useScriptOffline";
import SPXWorldNav from "../components/spx-script/SPXWorldNav";
import SPXBiblePanel from "../components/spx-script/SPXBiblePanel";
import SPXWorldMap from "../components/spx-script/SPXWorldMap";"""

if 'SPXWorldNav' not in content:
    content = content.replace(old_imports, new_imports)
    print("  Added imports")
else:
    print("  Imports already present")

# 2. Add DEFAULT_WORLD_DATA constant after DEFAULT_COMIC
old_after = "function getCurrentUser() {"
new_after = """const DEFAULT_WORLD_DATA = {
  characters: [],
  locations: [],
  factions: [],
  lore: [],
};

function getCurrentUser() {"""

if 'DEFAULT_WORLD_DATA' not in content:
    content = content.replace(old_after, new_after)
    print("  Added DEFAULT_WORLD_DATA")

# 3. Add state vars after existing state
old_state = "  const [generating, setGenerating] = useState(false);"
new_state = """  const [generating, setGenerating] = useState(false);
  const [scriptMode, setScriptMode] = useState("script"); // "script" | "world"
  const [worldData, setWorldData] = useState(DEFAULT_WORLD_DATA);
  const [selectedEntry, setSelectedEntry] = useState(null);
  const [mapPins, setMapPins] = useState([]);"""

if 'scriptMode' not in content:
    content = content.replace(old_state, new_state)
    print("  Added state vars")

# 4. Add mode toggle button to topbar (after credits badge)
old_badge = "        <div className=\"spx-script-credits-badge\">⬡ {credits} Credits</div>"
new_badge = """        <div className="spx-script-credits-badge">⬡ {credits} Credits</div>
        <div className="spx-script-vsep" />
        <button
          className={`spx-script-main-tab ${scriptMode === "script" ? "active" : ""}`}
          onClick={() => setScriptMode("script")}
          title="Script writing mode"
        >
          ✏️ SCRIPT
        </button>
        <button
          className={`spx-script-main-tab ${scriptMode === "world" ? "active" : ""}`}
          style={{ color: scriptMode === "world" ? "#FF6600" : undefined, borderBottomColor: scriptMode === "world" ? "#FF6600" : undefined }}
          onClick={() => setScriptMode("world")}
          title="World building mode"
        >
          🌍 WORLD
        </button>"""

if 'scriptMode === "script"' not in content:
    content = content.replace(old_badge, new_badge)
    print("  Added mode toggle buttons")

# 5. Replace left nav to show WorldNav in world mode
old_nav = """        {mainTab !== "gen" && (
          <SPXScriptNav mainTab={mainTab} script={script} comic={comic}
            selectedIssueId={selectedIssueId} selectedPageId={selectedPageId}
            onSelectPage={setSelectedPageId} onSelectIssue={setSelectedIssueId} drafts={drafts} />
        )}"""

new_nav = """        {mainTab !== "gen" && scriptMode === "script" && (
          <SPXScriptNav mainTab={mainTab} script={script} comic={comic}
            selectedIssueId={selectedIssueId} selectedPageId={selectedPageId}
            onSelectPage={setSelectedPageId} onSelectIssue={setSelectedIssueId} drafts={drafts} />
        )}
        {scriptMode === "world" && (
          <SPXWorldNav
            worldData={worldData}
            setWorldData={setWorldData}
            selectedEntry={selectedEntry}
            setSelectedEntry={setSelectedEntry}
            onSelectEntry={(entry) => { setSelectedEntry(entry); }}
          />
        )}"""

if 'SPXWorldNav' not in content.split('import')[0]:
    content = content.replace(old_nav, new_nav)
    print("  Wired World Nav")

# 6. Add World Map tab in center
old_gen = """        {mainTab === "gen" && (
          <SPXComicGenerator credits={credits} setCredits={setCredits}"""

new_gen = """        {scriptMode === "world" && mainTab !== "gen" && (
          <SPXWorldMap
            worldData={worldData}
            mapPins={mapPins}
            setMapPins={setMapPins}
            onSelectEntry={(entry) => setSelectedEntry(entry)}
          />
        )}
        {mainTab === "gen" && (
          <SPXComicGenerator credits={credits} setCredits={setCredits}"""

if 'SPXWorldMap' not in content.split('return')[1][:500] if 'return' in content else True:
    content = content.replace(old_gen, new_gen)
    print("  Wired World Map")

# 7. Replace right panel — show BiblePanel in world mode
old_right = """        {mainTab !== "gen" && (
          <SPXScriptRightPanel mainTab={mainTab} rpTab={rpTab} setRpTab={setRpTab}
            script={script} comic={comic} setComic={setComic}
            selectedIssueId={selectedIssueId} selectedPageId={selectedPageId}
            selectedPanelId={selectedPanelId} />
        )}"""

new_right = """        {mainTab !== "gen" && scriptMode === "script" && (
          <SPXScriptRightPanel mainTab={mainTab} rpTab={rpTab} setRpTab={setRpTab}
            script={script} comic={comic} setComic={setComic}
            selectedIssueId={selectedIssueId} selectedPageId={selectedPageId}
            selectedPanelId={selectedPanelId} />
        )}
        {scriptMode === "world" && (
          <SPXBiblePanel
            selectedEntry={selectedEntry}
            worldData={worldData}
            setWorldData={setWorldData}
            onOpenCanvas={() => window.open('/spx-canvas', '_blank')}
            on3DModel={() => window.open('/spx-3d-mesh', '_blank')}
          />
        )}"""

if 'SPXBiblePanel' not in content.split('return')[1] if 'return' in content else True:
    content = content.replace(old_right, new_right)
    print("  Wired Bible Panel")

# 8. Hide script center content in world mode
old_script = """        {mainTab === "script" && (
          <SPXScriptEditor script={script} setScript={setScript} format={format}"""

new_script = """        {mainTab === "script" && scriptMode === "script" && (
          <SPXScriptEditor script={script} setScript={setScript} format={format}"""

content = content.replace(old_script, new_script)

old_comic = """        {mainTab === "comic" && (
          <SPXComicEditor comic={comic} setComic={setComic}"""

new_comic = """        {mainTab === "comic" && scriptMode === "script" && (
          <SPXComicEditor comic={comic} setComic={setComic}"""

content = content.replace(old_comic, new_comic)
print("  Hid script/comic in world mode")

with open(PAGE, 'w') as f:
    f.write(content)

print("\nDone. Run: npm run build")
