#!/usr/bin/env python3
"""
install_broadcast_phase3.py
Installs:
1. RadioLiveViewer.js + CSS
2. song_log_routes.py backend
3. Wires viewer route in layout.js
4. Adds PRO Export button to RadioStationDashboard
5. Registers song_log_bp in app.py
6. Creates song log DB table migration
"""
import shutil, os

BASE = '/workspaces/SpectraSphere'
PAGES = f'{BASE}/src/front/js/pages'
STYLES = f'{BASE}/src/front/styles'
LAYOUT = f'{BASE}/src/front/js/layout.js'
APP = f'{BASE}/src/app.py'
DASHBOARD = f'{BASE}/src/front/js/pages/RadioStationDashboard.js'
API = f'{BASE}/src/api'

# 1. Copy files
shutil.copy('RadioLiveViewer.js', f'{PAGES}/RadioLiveViewer.js')
shutil.copy('RadioLiveViewer.css', f'{STYLES}/RadioLiveViewer.css')
shutil.copy('song_log_routes.py', f'{API}/song_log_routes.py')
print("Files copied")

# 2. Wire viewer route in layout.js
with open(LAYOUT) as f:
    content = f.read()

if 'RadioLiveViewer' not in content:
    content = content.replace(
        'import RadioLiveStudio from "./pages/RadioLiveStudio";',
        'import RadioLiveStudio from "./pages/RadioLiveStudio";\nimport RadioLiveViewer from "./pages/RadioLiveViewer";'
    )
    content = content.replace(
        '<Route path="/radio-live-studio/:stationId" element={<RadioLiveStudio />} />',
        '<Route path="/radio-live-studio/:stationId" element={<RadioLiveStudio />} />\n                                <Route path="/radio-live-viewer/:stationId" element={<RadioLiveViewer />} />'
    )
    print("Viewer route added")

with open(LAYOUT, 'w') as f:
    f.write(content)

# 3. Register song_log_bp in app.py
with open(APP) as f:
    app_content = f.read()

if 'song_log_bp' not in app_content:
    app_content = app_content.replace(
        'from api.radio_live_routes import radio_live_bp',
        'from api.radio_live_routes import radio_live_bp\nfrom api.song_log_routes import song_log_bp'
    )
    app_content = app_content.replace(
        'app.register_blueprint(radio_live_bp)',
        'app.register_blueprint(radio_live_bp)\napp.register_blueprint(song_log_bp)'
    )
    print("song_log_bp registered in app.py")

with open(APP, 'w') as f:
    f.write(app_content)

# 4. Add PRO Export + Song Log + View Audience buttons to dashboard
with open(DASHBOARD) as f:
    dash = f.read()

if 'pro-export' not in dash and 'PRO Report' not in dash:
    old_live_btn = 'Live Studio</a>'
    new_live_btn = '''Live Studio</a>
                    <a
                      href={`/api/radio/${station.id}/pro-export?pro=bmi&days=30`}
                      className="station-action-btn"
                      title="Export BMI/ASCAP Song Log"
                      style={{textDecoration:'none',marginLeft:6,padding:'6px 12px',background:'rgba(255,102,0,0.1)',border:'1px solid rgba(255,102,0,0.3)',color:'#FF6600',borderRadius:4,fontSize:12,fontWeight:700}}
                      download
                    >
                      📋 PRO Report
                    </a>'''
    dash = dash.replace(old_live_btn, new_live_btn)
    print("PRO Report button added to dashboard")

with open(DASHBOARD, 'w') as f:
    f.write(dash)

# 5. Create DB migration script
migration = '''#!/usr/bin/env python3
"""
Run this once to create the song_log table in your Railway PostgreSQL database.
Usage: python3 create_song_log_table.py
"""
import os, sys
sys.path.insert(0, '/workspaces/SpectraSphere/src')
os.environ.setdefault('FLASK_APP', 'app.py')

from app import app, db

with app.app_context():
    db.session.execute(db.text("""
        CREATE TABLE IF NOT EXISTS station_song_log (
            id SERIAL PRIMARY KEY,
            station_id INTEGER NOT NULL,
            title VARCHAR(255) NOT NULL DEFAULT 'Unknown Title',
            artist VARCHAR(255) NOT NULL DEFAULT 'Unknown Artist',
            composer VARCHAR(255),
            publisher VARCHAR(255),
            duration_seconds INTEGER DEFAULT 0,
            listener_count INTEGER DEFAULT 0,
            played_at TIMESTAMP DEFAULT NOW(),
            source VARCHAR(50) DEFAULT 'auto_dj',
            is_live BOOLEAN DEFAULT FALSE,
            show_title VARCHAR(255),
            created_at TIMESTAMP DEFAULT NOW()
        );
    """))
    db.session.execute(db.text("""
        CREATE INDEX IF NOT EXISTS idx_song_log_station_date
        ON station_song_log (station_id, played_at DESC);
    """))
    db.session.commit()
    print("station_song_log table created successfully")
'''

with open(f'{BASE}/create_song_log_table.py', 'w') as f:
    f.write(migration)
print("DB migration script created: create_song_log_table.py")

print("\nDone. Run:")
print("  npm run build")
print("  python3 create_song_log_table.py  (run once on Railway)")
