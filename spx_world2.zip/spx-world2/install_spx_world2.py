#!/usr/bin/env python3
"""
install_spx_world2.py
Adds Timeline, Relationship Web, Moodboard to World Mode
Replaces SPXWorldMap direct render with SPXWorldCenter tab switcher
"""
import shutil

PAGE = '/workspaces/SpectraSphere/src/front/js/pages/SPXScriptPage.js'
shutil.copy2(PAGE, PAGE + '.bak.world2')

with open(PAGE) as f:
    content = f.read()

# 1. Replace SPXWorldMap import with SPXWorldCenter
old_import = 'import SPXWorldMap from "../components/spx-script/SPXWorldMap";'
new_import = 'import SPXWorldCenter from "../components/spx-script/SPXWorldCenter";'

if 'SPXWorldCenter' not in content:
    content = content.replace(old_import, new_import)
    print("  Replaced SPXWorldMap import with SPXWorldCenter")
else:
    print("  SPXWorldCenter already imported")

# 2. Replace SPXWorldMap usage with SPXWorldCenter
old_usage = """        {scriptMode === "world" && mainTab !== "gen" && (
          <SPXWorldMap
            worldData={worldData}
            mapPins={mapPins}
            setMapPins={setMapPins}
            onSelectEntry={(entry) => setSelectedEntry(entry)}
          />
        )}"""

new_usage = """        {scriptMode === "world" && mainTab !== "gen" && (
          <SPXWorldCenter
            worldData={worldData}
            mapPins={mapPins}
            setMapPins={setMapPins}
            selectedEntry={selectedEntry}
            onSelectEntry={(entry) => setSelectedEntry(entry)}
          />
        )}"""

if old_usage in content:
    content = content.replace(old_usage, new_usage)
    print("  Replaced SPXWorldMap with SPXWorldCenter")
else:
    print("  WARNING: Could not find SPXWorldMap usage — check manually")
    # Try fallback
    content = content.replace(
        '<SPXWorldMap\n            worldData={worldData}\n            mapPins={mapPins}\n            setMapPins={setMapPins}\n            onSelectEntry={(entry) => setSelectedEntry(entry)}\n          />',
        '<SPXWorldCenter\n            worldData={worldData}\n            mapPins={mapPins}\n            setMapPins={setMapPins}\n            selectedEntry={selectedEntry}\n            onSelectEntry={(entry) => setSelectedEntry(entry)}\n          />'
    )
    print("  Tried fallback replacement")

with open(PAGE, 'w') as f:
    f.write(content)

print("\nDone. Run: npm run build")
