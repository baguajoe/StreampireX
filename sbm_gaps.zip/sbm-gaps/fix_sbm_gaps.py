import shutil, re

SRC = '/workspaces/SpectraSphere/src/front/js/component'
SBM = f'{SRC}/SamplerBeatMaker.js'

# Backup
shutil.copy2(SBM, SBM + '.bak.sbm_gaps')

with open(SBM) as f:
    content = f.read()

# 1. Add imports after StutterEngine
old = "import StutterEngine from './StutterEngine';"
new = """import StutterEngine from './StutterEngine';
import AIBeatAssistant from './AIBeatAssistant';
import ChordProgressionGenerator from './ChordProgressionGenerator';
import HumToSong from './HumToSong';
import VoiceMidiConverter from './VoiceMidiConverter';
import TextToSongGenerator from './TextToSongGenerator';"""

if 'VoiceMidiConverter' not in content:
    content = content.replace(old, new)
    print("  Added 5 imports")
else:
    print("  Imports already present")

# 2. Chords tab
content = content.replace(
    "{chordsComponent || <div style={{ color: '#5a7088', padding: '40px', textAlign: 'center' }}>🎼 Chord Progression Generator — open via DAW Sampler view</div>}",
    """{chordsComponent || <ChordProgressionGenerator
              isEmbedded={true}
              onSendToTrack={(chords) => console.log('chords:', chords)}
            />}"""
)
print("  Patched Chords tab")

# 3. AI Beats tab
content = content.replace(
    "{aiBeatsComponent || <div style={{ color: '#5a7088', padding: '40px', textAlign: 'center' }}>🤖 AI Beat Assistant — open via DAW Sampler view</div>}",
    """{aiBeatsComponent || <AIBeatAssistant
              bpm={bpm}
              isEmbedded={true}
              onApplyPattern={(pattern) => console.log('pattern:', pattern)}
            />}"""
)
print("  Patched AI Beats tab")

# 4. Voice MIDI tab
content = content.replace(
    "{voiceMidiComponent || <div style={{ color: '#5a7088', padding: '40px', textAlign: 'center' }}>🎤 Voice MIDI — open via DAW Sampler view</div>}",
    """{voiceMidiComponent || <VoiceMidiConverter
              audioContext={ctxRef.current}
              isEmbedded={true}
              onNote={(note) => console.log('voice note:', note)}
              onAssignToPad={(note) => {
                if (activePad !== null) console.log('assign note to pad', activePad, note);
              }}
            />}"""
)
print("  Patched Voice MIDI tab")

# 5. Hum to Song tab
content = content.replace(
    "{humToSongComponent || <div style={{ color: '#5a7088', padding: '40px', textAlign: 'center' }}>🎵 Hum to Song — open via AI Tools sidebar</div>}",
    """{humToSongComponent || <HumToSong
              isEmbedded={true}
            />}"""
)
print("  Patched Hum to Song tab")

# 6. Text to Song tab
content = content.replace(
    "{textToSongComponent || <div style={{ color: '#5a7088', padding: '40px', textAlign: 'center' }}>✍️ Text to Song — open via AI Tools sidebar</div>}",
    """{textToSongComponent || <TextToSongGenerator
              isEmbedded={true}
              onLoadSample={(buffer, name) => {
                if (typeof onLoadSample === 'function') onLoadSample(buffer, name, null, null);
              }}
              onLoadToPad={(buffer, name) => {
                if (activePad !== null) loadBufferToPad(activePad, buffer, name);
              }}
            />}"""
)
print("  Patched Text to Song tab")

with open(SBM, 'w') as f:
    f.write(content)

print("\nAll 5 gaps closed in SamplerBeatMaker.js")
