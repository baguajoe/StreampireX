#!/usr/bin/env python3
"""
SPX Script v2 Install Script
Run from repo root: python3 install_spx_script.py
"""
import os, shutil, sys

ROOT = os.path.dirname(os.path.abspath(__file__))

FILES = {
    "SPXScriptPage.js":           "src/front/js/pages/SPXScriptPage.js",
    "SPXScriptEditor.js":         "src/front/js/components/spx-script/SPXScriptEditor.js",
    "SPXComicEditor.js":          "src/front/js/components/spx-script/SPXComicEditor.js",
    "SPXComicGenerator.js":       "src/front/js/components/spx-script/SPXComicGenerator.js",
    "SPXScriptNav.js":            "src/front/js/components/spx-script/SPXScriptNav.js",
    "SPXScriptRightPanel.js":     "src/front/js/components/spx-script/SPXScriptRightPanel.js",
    "SPXCollabBar.js":            "src/front/js/components/spx-script/SPXCollabBar.js",
    "SPXOfflineIndicator.js":     "src/front/js/components/spx-script/SPXOfflineIndicator.js",
    "useScriptCollaboration.js":  "src/front/js/hooks/useScriptCollaboration.js",
    "useScriptOffline.js":        "src/front/js/hooks/useScriptOffline.js",
    "fdxUtils.js":                "src/front/js/utils/fdxUtils.js",
    "spx-script.css":             "src/front/styles/spx-script.css",
    "script_routes.py":           "src/api/routes/script_routes.py",
    "script_collab_ws.py":        "src/api/routes/script_collab_ws.py",
}

def find_root():
    c = os.getcwd()
    for _ in range(6):
        if os.path.exists(os.path.join(c,"package.json")) and os.path.exists(os.path.join(c,"src")):
            return c
        c = os.path.dirname(c)
    return os.getcwd()

def copy_files(root):
    ok, skip = [], []
    for src, dst in FILES.items():
        s = os.path.join(ROOT, src)
        d = os.path.join(root, dst)
        if not os.path.exists(s):
            print(f"  MISSING {src}"); skip.append(src); continue
        os.makedirs(os.path.dirname(d), exist_ok=True)
        if os.path.exists(d): shutil.copy2(d, d+".bak")
        shutil.copy2(s, d)
        print(f"  OK  {src} -> {dst}"); ok.append(dst)
    return ok, skip

def patch_router(root):
    for rel in ["src/front/js/layout.js","src/front/js/Layout.js","src/front/js/AppRouter.js","src/front/js/index.js","src/front/js/App.js"]:
        f = os.path.join(root, rel)
        if not os.path.exists(f): continue
        c = open(f).read()
        if "SPXScriptPage" in c: print(f"  Router already patched ({rel})"); return
        lines = c.split("\n")
        li = max((i for i,l in enumerate(lines) if l.strip().startswith("import ")),default=0)
        lines.insert(li+1,'import SPXScriptPage from "./pages/SPXScriptPage";')
        nc = "\n".join(lines)
        for t in ["</Routes>","</Switch>"]:
            if t in nc:
                nc = nc.replace(t,'                <Route path="/spx-script" element={<SPXScriptPage />} />\n                '+t,1); break
        shutil.copy2(f,f+".bak"); open(f,"w").write(nc)
        print(f"  Router patched: {rel}"); return
    print("  Could not auto-patch router — add SPXScriptPage route manually")

def patch_flask(root):
    for rel in ["src/api/app.py","src/app.py","src/api/__init__.py"]:
        f = os.path.join(root, rel)
        if not os.path.exists(f): continue
        c = open(f).read()
        if "script_bp" in c: print(f"  Flask already patched ({rel})"); return
        lines = c.split("\n")
        li = max((i for i,l in enumerate(lines) if l.strip().startswith(("from ","import "))),default=0)
        ri = max((i for i,l in enumerate(lines) if "register_blueprint" in l),default=0)
        lines.insert(li+1,"from .routes.script_collab_ws import register_collab_ws")
        lines.insert(li+1,"from .routes.script_routes import script_bp")
        ins = ri+3 if ri else len(lines)
        lines.insert(ins,"register_collab_ws(sock)")
        lines.insert(ins,"app.register_blueprint(script_bp)")
        shutil.copy2(f,f+".bak"); open(f,"w").write("\n".join(lines))
        print(f"  Flask patched: {rel}"); return
    print("  Could not auto-patch Flask — add script_bp + register_collab_ws manually")

if __name__=="__main__":
    root = sys.argv[1] if len(sys.argv)>1 else find_root()
    print(f"\nRepo root: {root}\n")
    ok,skip = copy_files(root)
    patch_router(root)
    patch_flask(root)
    print(f"\nDone. {len(ok)} files installed, {len(skip)} skipped.")
    print("\nNext steps:")
    print("  pip install flask-sock")
    print("  Add REPLICATE_API_TOKEN and REACT_APP_WS_URL to .env")
    print("  npm run build\n")
