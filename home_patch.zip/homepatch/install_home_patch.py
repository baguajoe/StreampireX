#!/usr/bin/env python3
"""
install_home_patch.py
1. Backs up home.js
2. Runs the patch
3. Appends CSS additions to home.css
"""
import shutil, os

BASE = '/workspaces/SpectraSphere'
HOME = f'{BASE}/src/front/js/pages/home.js'
CSS = f'{BASE}/src/front/styles/home.css'

# Backup
shutil.copy(HOME, HOME + '.hero_backup2')
print("✓ Backed up home.js")

# Run patch
import subprocess
result = subprocess.run(['python3', 'homepatch/patch_home.py'], capture_output=True, text=True)
print(result.stdout)
if result.stderr:
    print("STDERR:", result.stderr)

# Append CSS additions
with open('homepatch/home_additions.css') as f:
    additions = f.read()

with open(CSS, 'r') as f:
    existing = f.read()

if 'broadcast-spotlight' not in existing:
    with open(CSS, 'a') as f:
        f.write('\n\n' + additions)
    print("✓ CSS additions appended to home.css")
else:
    print("✓ CSS additions already present")

print("\n✅ Done. Run: npm run build")
